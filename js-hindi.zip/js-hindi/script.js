let firstname = '4'
let lastname = 'tiwari'
let age = 30
let a = true
let userIntro = 'my name is ' + firstname + ' ' + lastname + ' ' + 'i am' + ' ' + age + ' ' +  'years old.'

